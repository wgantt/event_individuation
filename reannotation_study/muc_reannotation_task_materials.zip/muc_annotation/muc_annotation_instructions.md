# Task Instructions

The purpose of this task is to determine the number of instances of
each of the following MUC template types that are present in a target
document:

  - Arson
  - Attack
  - Bombing
  - Kidnapping
  - Robbery

Importantly, each document will contain *at least one template*, but
may contain more than one. Moreover, all documents contain templates of
only a single type.

(Note: even though they are part of the original ontology, we are
omitting the "hijacking" and "forced work stoppage" templates from
annotation, as they have inadequate support in the data.)

While the original documentation does not appear to provide
detailed descriptions of the template types, we present below some
excerpts from that documentation (which can be found in full
[here](https://github.com/xinyadu/gtt/tree/master/data/muc/raw_files/muc34/TASK/TASKDOC)),
which may be helpful in understanding when each template applies.
Please read these excerpts carefully before beginning your annotation.
Note that some of them make reference to MUC-3; this is because all
of the training documents and many aspects of the annotation were
unchanged between MUC-3 and MUC-4.

As you will be able to infer from the instructions below, location
can be a factor in determining the appropriate template annotation
for a document, even though it is not one of the slots used for
scoring. MUC-3 and MUC-4 had fairly specific criteria for what
counted as a valid filler for the location slot. Please consult
the `set-list-location.v4` file to understand these criteria.

If anything remains unclear after reading these instructions, please
feel free to consult the complete documentation for clarification,
which can be found at the following URL:
https://github.com/xinyadu/gtt/tree/master/data/muc/raw_files/muc34

I have selected 42 documents from the MUC-4 training split for you
to annotate. These are provided together in the `muc_sample.json`
file. Along with a document identifier (`docid`) and document text
(`doctext`), there are eight additional fields: one for each of the
six template types, one for the dateline of the document (which is
important for the "recency" requirement described in **Excerpt 1**
below), and one for comments. For each template type,
you should indicate how many templates of that type you think are
present in the document by entering that number in the field
corresponding to that template type. Note that each field defaults to
0, so you can leave this as is if you do not think there are any
templates of that type for a particular document.

The `comments` field is for you to describe the rationale behind
your annotation. Please do update this field for all documents
with a short summary of your rationale for marking the number of
templates you did (of whatever type you did), 

To annotate, please make a copy of the `muc_sample.json` file (or
modify it directly) and rename it `muc_sample_<your_name>.json`.
Enter your annotations directly in the JSON and return the file to
me when finished.

Thanks!


## Excerpts

### Excerpt 1

**Preface**: *This excerpt is about when a template should be annotated in
general.*


WHAT CONSTITUTES A "RELEVANT" INCIDENT?

Relevant incidents are, in general, violent acts perpetrated with
  political aims and a motive of intimidation.  These are acts of terrorism.
  Here is an official, "schoolbook" definition of terrorism:

> "a sudden, unexpected act of shocking, calculated, and unlawful
violence, or the plausible threat of such violence, by an illegal,
subnational, clandestine group -- usually carried out in a
peaceful, civilian environment, be it urban, rural, in the air or
on a body of water -- against certain noncombatants or targets
that represent or symbolize a certain country, but sometimes
indiscrimately against bystanders or passersby at a particular
location, with the intention of garnering publicity, propagandizing
a cause, and intimating as many people as possible in order to
attain social, political, or strategic objectives."

> -Rex A. Hudson, "Dealing with International
			Hostage-Taking: Alternatives to Reactive
			Counterterrorist Assaults," International
			Terrorism, Vol. 12, 1990.

This has been turned into more of an operational definition by
  widening the schoolbook definition somewhat and making some rather arbitrary
  distinctions.  Your advice on how to improve on this operational definition
  is welcome.

1. Terrorist acts may be perpetrated by an "illegal,
  subnational, clandestine group," which includes known guerrilla and
  drug-trafficking organizations.  Their targets may be just about
  anything/anybody except (a) another such group or member of such a
  group or (b) a military/police installation or force (with the same
  nationality as the perpetrator), or a member of such a force, in which
  case the incident is presumed to be a purely guerrilla act and is not
  relevant to the MUC-3 terrorist incident database.  Thus, killings of
  drug traffickers will not be included in the database (by exception a,
  above), nor will "clashes" between guerrilla groups and the military
  (by exception b, above).

 	However, if a guerrilla warfare incident happens to affect
  civilian personnel or property, whether intentionally or accidentally,
  the incident becomes relevant and should be included in the database.
  In these cases, the database should contain information on both the
  military and the nonmilitary targets.

	Similarly, the database will include incidents of sabotage on
  a nation's infrastructure.  It will also include incidents
  perpetrated against individuals who are former members of the
  military, e.g., a murder perpetrated against a retired general.

	Sometimes an article gives mixed reports, e.g., a "terrorist
  attack" on a bridge guarded by the national (military) police.  In a
  case such as this, which could be interpreted as a case of terrorism
  (sabotage of the nation's infrastructure) or of guerrilla warfare
  (attack on a physical target of military importance), we will
  consider the physical target to be nonmilitary and will include the
  incident in the database.

2. Under certain circumstances, the perpetrator may be a member of
  the government, including the military.  This is the case when the target is
  civilian.

3. Sometimes the perpetrator is not identified and no language
  is used to indicate that the act is *not* being attributed to
  "terrorists," "extremists," "subversives," "guerrillas," etc.  In
  these cases, as long as the act itself is of one of the expected
  types and the target(s) is/are not exclusively military, the incident
  will be presumed to be a possible terrorist act and is to be included
  in the database.

4. The articles in the MUC-3 corpus originate in many different
  parts of the world, but they all emphasize something about one of the nine
  Latin American countries of interest (El Salvador, Guatemala, Honduras,
  Argentina, Bolivia, Chile, Colombia, Ecuador, Peru).  However, only
  incidents whose perpetrator(s), target(s), or location "belong to" one of
  the nine countries of interest belong in the MUC-3 database.  Thus, an
  incident perpetrated against a human target who is a citizen of one of those
  countries may belong in the database even if that person is attacked while
  he's in a different country.  Or an incident perpetrated against the embassy
  of one of those nine countries may belong in the database, no matter where
  that embassy is located.

5. Only terrorist acts (and attempted acts) that are reported as
  factual are to be included in the database.  An incident is *not* to be
  recorded in the database if the article discredits the story or cites a
  source that discredits the story.  (However, if the article also cites a
  source that *supports* the story, that version of the story should go in the
  database.)  Rumors are to be excluded.

6. An incident is to be recorded in the database only if it is
  "recent." The intent is to include only information that is new or updated.
  We define "recent" to mean that either (a) it occurred within two months of
  the date of the article or (b) new information is being provided in the
  article on an incident that occured more than two months prior, such as new
  suspects being brought forth as the perpetrators of an old crime.  However,
  there are a number of articles that fail to mention the date of the
  incidents, some of which are, in fact, recent.  Therefore, if there is no
  indication that the information is not recent or if there is no indication
  that the information is being given only to provide historical context (as
  indicated by phrases such as "Let us recall that..."), the incident should
  go in the database.

  [REMINDER: The "dateline" field for each article should be used as the
   reference point for determining "recency." --Will]

7. An incident is to be recorded in the database only if the
  article's description of it is "specific."  Generic descriptions of
  incidents like "terrorist attacks on the Cano Limon-Covenas oil pipeline"
  and summary descriptions like "the total persons kidnapped in Colombia over
  the last 6 weeks was 85" are to be excluded.

	The articles sometimes give useful information about a specific
  incident but provide very few details.  Therefore, as long as all the other
  criteria are met, we will include any incident that at least indicates the
  nature of the target or the nature of the attack.  Thus, an article
  whose only reference to an incident is "an attack perpetrated by a
  subversive group" or "the tragic incident at Uchiza" would be excluded, but
  an article that says "Last night there were fewer attacks on stores and
  electric towers in the capital" or "a UCR district headquarters in Buenos
  Aires province was completely destroyed by a bomb explosion" would be
  included.

	Here are two further examples of texts that do *not* warrant
  generation of templates: "As of 0500 GMT today, the police had
  received reports of two other explosions in two La Paz neighborhoods"
  (the nature of the explosion isn't mentioned, and the target isn't
  mentioned either); "the bombing on San Salvador's neighborhoods" (the
  prepositional phrase may be interpreted as conveying the target as
  well as the location, but as a target, it's too general -- any location
  name that is on the set list cannot serve as a target ID, with the
  exception of farm names).

### Excerpt 2

**Preface**: *This excerpt concerns when multiple templates should be annotated
for a given document*:

  If an article discusses more than one relevant type of terrorist incident,
    each such incident should be captured in a separate template.
  If an article discusses more than one instance of the same relevant type
    of terrorist incident, each such incident should be captured in a
    separate template.  A "separate instance" is one which has a different
    filler for the location, date, category, or perpetrator slot.  If no
    distinctions of these kinds are made in the text, the instances should
    be incorporated into a single template, e.g., if the article describes
    "attacks" by "rebels" on "ten power stations" and does not give varying
    information on the location of those targets, etc.  Note that the level
    of granularity is defined by what can go in a slot; thus, an article
    that describes two bombings on targets on different streets in the
    same neighborhood should be captured in one template rather than two,
    since the location slot cannot have a filler that is at the level of
    granularity of a street.

### Excerpt 3

**Preface**: *This excerpt contains some notes about particular template types
and when they apply. As descriptions, they are obviously inadequate. Beyond what
is provided here, please use your best judgment in determining when each
applies. (NOTE: "attempted bombing" is not a distinct template type; the
information about these cases is just meant to offer additional context
for the bombing template type.)*

ATTACK -- The ATTACK incident type should be used only when a terrorist
  incident clearly does not fall into one of the other categories.
  
BOMBING -- This is not intended to be used for aerial bombing, i.e.,
  bombs dropped from airplanes; use ATTACK instead, with
  AERIAL BOMB as the instrument.
  
KIDNAPPING -- This covers abduction/detention
  in general, e.g., hostage-taking, and abduction with the intent to
  bring someone before a kangaroo court.

ATTEMPTED BOMBING -- If a bomb is planted by the perpetrators but
  deactivated by someone else or moved and intentionally set off by
  someone else, the event qualifies as an ATTEMPTED BOMBING, and
  any damage or injury that results goes in the EFFECT slot.
  This event type also applies in situations where the perpetrators
  are trying to plant a bomb somewhere but get stopped in the process.

### Excerpt 4

**Preface**: *This excerpt describes the complete list of slots actually
annotated for each template. I include it mainly for completeness.*

2.0  DEFINITIONS OF SLOT TYPES

  0.  MESSAGE: ID -- The first line of the message, e.g., DEV-MUC3-0001 (NOSC).
  This slot serves as an index and is not scored in its own right.
  1.  MESSAGE: TEMPLATE -- A number that distinguishes the templates for a given
  message.  In the answer key, the word OPTIONAL in parentheses after 
  the template number indicates that there is significant doubt whether
  the incident belongs in the database.
  2.  INCIDENT: DATE -- The date of incident (according to local time, not
  Greenwich Mean Time).
  3.  INCIDENT: LOCATION -- The place where the incident occurred.
  4.  INCIDENT: TYPE -- A terrorist act reported on in the message.                  
  5.  INCIDENT: STAGE OF EXECUTION -- An indicator of whether the terrorist
  act was accomplished, attempted, or merely threatened.
  6.  INCIDENT: INSTRUMENT ID -- A device used by the perpetrator(s) in carrying
  out the terrorist act.
  7.  INCIDENT: INSTRUMENT TYPE -- The category that the instrument fits into.
  8.  PERP: INCIDENT CATEGORY -- The subcategory of terrorism that the incident 
  fits into, as determined by the nature of the perpetrators.
  9.  PERP: INDIVIDUAL ID -- A person responsible for the incident.
  10. PERP: ORGANIZATION ID -- An organization responsible for the incident.
  11. PERP: ORGANIZATION CONFIDENCE -- The way a perpetrator organization is viewed
  in the message.
  12. PHYS TGT: ID -- A thing (inanimate object) that was attacked.
  13. PHYS TGT: TYPE -- The category that the physical target fits into.
  14. PHYS TGT: NUMBER -- The number of physical targets with a particular ID and TYPE.
  15. PHYS TGT: FOREIGN NATION -- The nationality of a physical target, if
  the nationality is identified in the article and if it's different from country
  where incident occurred.  
  16. PHYS TGT: EFFECT OF INCIDENT -- The impact of the incident on a physical
  target.
  17. PHYS TGT: TOTAL NUMBER -- The total number of physical targets.
  18. HUM TGT: NAME -- The name of a person who was the obvious or apparent
  target of the attack or who became a victim of the attack.
  19. HUM TGT: DESCRIPTION -- The title or role of a named human target or a general
  description of an unnamed human target.
  20. HUM TGT: TYPE -- The category that the human target fits into.
  21. HUM TGT: NUMBER -- The number of human targets with a particular NAME,
  DESCRIPTION, and TYPE.
  22. HUM TGT: FOREIGN NATION -- The nationality of a human target, if
  the nationality is identified in the article and if it's different from country 
  where incident occurred.  
  23. HUM TGT: EFFECT OF INCIDENT -- The impact of the incident on a human
  target(s).
  24. HUM TGT: TOTAL NUMBER -- The total number of human targets.

